const express = require('express'); 
const bodyParser = require('body-parser');
const app = express(); 
app.use(bodyParser.json());

let Livros = [];

 app.get('/Livros', (req, res) => { 
    res.json(Livros); 
    });
    
app.get('/Livros/:Titulo', (req, res) => { 
    const { Titulo } = req.params; 
    const Livro = Livros.find(v => v.Titulo === Titulo); 
    if (Livro) { 
    res.json(Livro); 
    } else { 
    res.status(404).json({ message: 'Livro não encontrado.' }); 
    } 
    });

app.post('/Livros', (req, res) => { 
    const { Titulo, Autor, Genero, ano } = req.body; 
    const Livro= { Titulo, Autor, Genero, ano }; 
    Livros.push(Livro); 
    res.status(201).json({ message: 'Livro cadastrado com sucesso.' }); 
    });

app.put('/Livros/:Titulo', (req, res) => { 
    const { Titulo } = req.params; 
    const { Autor, Genero, ano } = req.body; 
    const Livro= Livros.find(v => v.Titulo === Titulo); 
    if (Livro) { 
    Livro.Autor = Autor || Livro.Autor; 
    Livro.Genero = Genero || Livro.Genero; 
    Livro.ano = ano || Livro.ano; 
    res.json({ message: 'Informações do Livro atualizadas com sucesso.' });
    } else {
    res.status(404).json({ message: 'Livro não encontrado.' }); 
    } 
    });
        
    app.delete('/Livros/:Titulo', (req, res) => { 
        const { Titulo } = req.params; 
        const LivroIndex = Livros.findIndex(v => v.Titulo === Titulo); 
        if (LivroIndex !== -1) { 
            Livros.splice(LivroIndex, 1); 
        res.json({ message: 'Livro excluído com sucesso.' }); 
        } else { 
        res.status(404).json({ message: 'Livro não encontrado.' }); 
        } 
        });

        const port = 3000; 
app.listen(port, () => { 
console.log(`Servidor rodando em http://localhost:${port}`); 
});


        